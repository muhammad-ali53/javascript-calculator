let screen = document.getElementById("screen");

function insert(value){
    screen.value += value;
}

function clearAll(){
    screen.value = "";
}

function del(){
    screen.value = screen.value.slice(0,-1);
}

function calculate(){
    try{
        screen.value = eval(screen.value);
    }catch{
        screen.value = "Error";
    }
}

function scientific(fn){
    try{
        let value = parseFloat(screen.value);
        if(fn === "sin") screen.value = Math.sin(value);
        if(fn === "cos") screen.value = Math.cos(value);
        if(fn === "tan") screen.value = Math.tan(value);
        if(fn === "log") screen.value = Math.log10(value);
        if(fn === "sqrt") screen.value = Math.sqrt(value);
    }catch{
        screen.value = "Error";
    }
}
